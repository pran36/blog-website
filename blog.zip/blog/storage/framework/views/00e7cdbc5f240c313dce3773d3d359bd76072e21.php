
<?php $__env->startSection('content'); ?>
<div class="az-content az-content-dashboard">
    <div class="container">
      <div class="az-content-body">
        <form action='/create/store' method="POST">
            <?php echo csrf_field(); ?>
            Post Title: <input type = 'text' name='post_title' class="form-control"><br><br>
            Post Content: <textarea name="post_content" class="form-control"></textarea><br><br>
            Published by:<input type = 'text' name='publisher' class="form-control"><br><br>
            Publisher Post: <input type = 'text' name='publisher_post' class="form-control"><br><br>
            <input type="submit" name="submit" value="save" class="btn btn-gray-700 btn-block"><br><br>
        </form>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Xampp\htdocs\blog website\blog\resources\views/create.blade.php ENDPATH**/ ?>