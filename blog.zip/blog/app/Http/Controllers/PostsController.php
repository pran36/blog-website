<?php

namespace App\Http\Controllers;

use App\Models\Posts;
use Illuminate\Http\Request;

class PostsController extends Controller
{
    public function index(){
        $posts1 = Posts::latest()->take(1)->get();
        $posts2 = Posts::latest()->skip(1)->take(2)->get();
        $posts3 = Posts::latest()->skip(3)->take(3)->get();
        // return $posts;
        return view('posts',['posts1'=>$posts1,'posts2'=>$posts2,'posts3'=>$posts3]);
    }
    public function view(Posts $post){
        return view('read',['post'=>$post]);
    }
}
